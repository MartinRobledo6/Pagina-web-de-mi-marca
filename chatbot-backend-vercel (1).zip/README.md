# Backend para martcode.dev Chatbot (Vercel)

## 🚀 ¿Qué hace?
Este backend recibe los mensajes del chatbot desde el frontend, los manda a OpenAI y devuelve la respuesta.

## 🧩 ¿Cómo usarlo?

1. Subí esta carpeta como un repositorio en GitHub.
2. Desde Vercel, creá un nuevo proyecto con ese repo.
3. En Settings > Environment Variables, agregá:

   - `OPENAI_API_KEY` → tu clave secreta de OpenAI

4. Deploy y listo.

👉 La URL de tu endpoint será: `https://TU_PROYECTO.vercel.app/api/chat`

No olvides pegar esa URL en tu HTML en lugar de `/api/chat`.